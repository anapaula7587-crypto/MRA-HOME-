package com.mrahome.envios;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;

import java.util.Calendar;

public class ReminderScheduler {

    public static final String TYPE_NIGHT = "night";
    public static final String TYPE_MORNING = "morning";

    public static void scheduleAll(Context context) {
        schedule(context, TYPE_NIGHT, 22, 0, 2200);
        schedule(context, TYPE_MORNING, 6, 30, 630);
    }

    public static void schedule(Context context, String type, int hour, int minute, int requestCode) {
        AlarmManager alarmManager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        if (alarmManager == null) return;

        Intent intent = new Intent(context, ReminderReceiver.class);
        intent.putExtra("type", type);

        PendingIntent pendingIntent = PendingIntent.getBroadcast(
            context,
            requestCode,
            intent,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        Calendar now = Calendar.getInstance();
        Calendar next = Calendar.getInstance();
        next.set(Calendar.HOUR_OF_DAY, hour);
        next.set(Calendar.MINUTE, minute);
        next.set(Calendar.SECOND, 0);
        next.set(Calendar.MILLISECOND, 0);

        if (!next.after(now)) {
            next.add(Calendar.DAY_OF_YEAR, 1);
        }

        alarmManager.setAndAllowWhileIdle(
            AlarmManager.RTC_WAKEUP,
            next.getTimeInMillis(),
            pendingIntent
        );
    }

    public static void scheduleNext(Context context, String type) {
        if (TYPE_NIGHT.equals(type)) {
            schedule(context, TYPE_NIGHT, 22, 0, 2200);
        } else {
            schedule(context, TYPE_MORNING, 6, 30, 630);
        }
    }
}
