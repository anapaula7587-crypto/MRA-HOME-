package com.mrahome.envios;

import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.os.Build;

import androidx.core.app.NotificationCompat;

import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Iterator;
import java.util.Locale;

public class ReminderReceiver extends BroadcastReceiver {

    private static final String DB_URL = "https://mra-envios-default-rtdb.firebaseio.com/pedidos.json";

    @Override
    public void onReceive(Context context, Intent intent) {
        String type = intent.getStringExtra("type");
        if (type == null) type = ReminderScheduler.TYPE_MORNING;

        final String finalType = type;
        final PendingResult pendingResult = goAsync();

        new Thread(() -> {
            try {
                int count = countPending(finalType);
                if (count > 0) {
                    showNotification(context, finalType, count);
                }
            } catch (Exception ignored) {
            } finally {
                ReminderScheduler.scheduleNext(context, finalType);
                pendingResult.finish();
            }
        }).start();
    }

    private int countPending(String type) throws Exception {
        HttpURLConnection conn = (HttpURLConnection) new URL(DB_URL).openConnection();
        conn.setConnectTimeout(10000);
        conn.setReadTimeout(10000);
        conn.setRequestMethod("GET");

        BufferedReader reader = new BufferedReader(new InputStreamReader(conn.getInputStream()));
        StringBuilder sb = new StringBuilder();
        String line;
        while ((line = reader.readLine()) != null) sb.append(line);
        reader.close();
        conn.disconnect();

        String json = sb.toString();
        if (json.equals("null") || json.isEmpty()) return 0;

        JSONObject root = new JSONObject(json);

        Calendar target = Calendar.getInstance();
        if (ReminderScheduler.TYPE_NIGHT.equals(type)) {
            target.add(Calendar.DAY_OF_YEAR, 1);
        }

        String targetDate = new SimpleDateFormat("yyyy-MM-dd", Locale.US).format(target.getTime());

        int count = 0;
        Iterator<String> keys = root.keys();
        while (keys.hasNext()) {
            String key = keys.next();
            JSONObject order = root.optJSONObject(key);
            if (order == null) continue;

            boolean enviado = order.optBoolean("enviado", false);
            String limite = order.optString("limite", "");

            if (!enviado && targetDate.equals(limite)) {
                count++;
            }
        }
        return count;
    }

    private void showNotification(Context context, String type, int count) {
        String title;
        String text;

        if (ReminderScheduler.TYPE_NIGHT.equals(type)) {
            title = "Mra Envios • pedidos de amanhã";
            text = count == 1
                ? "Você tem 1 pedido para enviar amanhã."
                : "Você tem " + count + " pedidos para enviar amanhã.";
        } else {
            title = "Mra Envios • envios de hoje";
            text = count == 1
                ? "Hoje você tem 1 pedido para enviar."
                : "Hoje você tem " + count + " pedidos para enviar.";
        }

        Intent openApp = new Intent(context, MainActivity.class);
        openApp.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);

        PendingIntent contentIntent = PendingIntent.getActivity(
            context,
            ReminderScheduler.TYPE_NIGHT.equals(type) ? 9001 : 9002,
            openApp,
            PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE
        );

        NotificationCompat.Builder builder = new NotificationCompat.Builder(context, "mra_envios_prazos")
            .setSmallIcon(R.mipmap.ic_launcher)
            .setContentTitle(title)
            .setContentText(text)
            .setStyle(new NotificationCompat.BigTextStyle().bigText(text))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .setAutoCancel(true)
            .setContentIntent(contentIntent);

        NotificationManager manager =
            (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);

        if (manager != null) {
            int notificationId = ReminderScheduler.TYPE_NIGHT.equals(type) ? 2200 : 630;
            manager.notify(notificationId, builder.build());
        }
    }
}
